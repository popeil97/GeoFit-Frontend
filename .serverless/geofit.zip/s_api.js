
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'geofitclubteam',
  applicationName: 'geofit-frontend',
  appUid: 'hYjXHsG4XfJp6VfDMB',
  orgUid: 'Yj7x6jv0jvqQ0sv0RJ',
  deploymentUid: 'cf97236e-8b40-4cd2-839a-3724c46d71f8',
  serviceName: 'geofit',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'production',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.16',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'geofit-production-api', timeout: 10 };

try {
  const userHandler = require('./lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.universal, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}