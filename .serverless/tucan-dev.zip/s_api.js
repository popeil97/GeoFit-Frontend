
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'geofitclubteam',
  applicationName: 'tucan-dev',
  appUid: 'GCBtDLbtRZ45hgs8PD',
  orgUid: 'Yj7x6jv0jvqQ0sv0RJ',
  deploymentUid: '8a71c20b-7793-4d56-8de2-8f47b464ec81',
  serviceName: 'tucan-dev',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.16',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'tucan-dev-dev-api', timeout: 10 };

try {
  const userHandler = require('./lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.universal, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}