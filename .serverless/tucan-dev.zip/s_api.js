
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'geofitclubteam',
  applicationName: 'tucan-dev',
  appUid: 'GCBtDLbtRZ45hgs8PD',
  orgUid: 'Yj7x6jv0jvqQ0sv0RJ',
  deploymentUid: '85c9966c-0453-49a5-8505-e6e56faca9c4',
  serviceName: 'tucan-dev',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.16',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'tucan-dev-dev-api', timeout: 10 };

try {
  const userHandler = require('./lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.universal, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}