export const environment = {
  production: true,
  apiUrl: 'https://api-dev.tucan.fitness'
};
